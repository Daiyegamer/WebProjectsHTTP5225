<?php 
$connect = mysqli_connect(
          'localhost', 'u235331216_AdilSurve', 'D@iye786!786', 'u235331216_tor_tra_vol'
        );
        if(!$connect){
          echo 'Error Code: ' . mysqli_connect_errno();
          echo 'Error Message: ' . mysqli_connect_error();
          exit;
        }
        ?>